﻿namespace Newsletter.Reporting.Api.Entities;

public enum ArticleEventType
{
    View = 1
}