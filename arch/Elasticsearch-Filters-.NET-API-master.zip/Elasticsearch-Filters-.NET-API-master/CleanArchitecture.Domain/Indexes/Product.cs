﻿namespace CleanArchitecture.Domain.Indexes
{
    public class Product
    {
        public string Name { get; set; }
        public string Brand { get; set; }
        public string[] Colors { get; set; }
        public double Price { get; set; }
    }
}
