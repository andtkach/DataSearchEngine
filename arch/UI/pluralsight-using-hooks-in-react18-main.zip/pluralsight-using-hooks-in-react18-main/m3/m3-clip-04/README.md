# Rules of Hooks Discussion

I have noticed that sometimes the .eslintrc.json file does not show up after
creating the project with `npx create-next-app@latest`. If that happens to
you I suggest copying that file from this git repo into your project.

That is what worked for me.