# No Code For This Module

This module is attempt #2 at useState and it fails so no code is included. I did think about including this code, but I think that might confuse people if I included code that didn't work, some people might not understand when it doesn't work.

If you want to try these examples yourself to create the non-working code, you can take the example from the previous clip and modify it as I did in the video.