import Layout from "./components/layout/Layout";

const App = ({ url }) => {
  return <Layout url={url} />;
};

export default App;
